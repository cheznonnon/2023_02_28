// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_MOVE
#define _H_NONNON_WIN32_WIN_MOVE




#include "./_debug.c"
#include "./property.c"
#include "./stdsize.c"
#include "./style.c"




// internal
void
n_win_move_patch_button( HWND hgui, n_type_gfx *x, n_type_gfx *y, n_type_gfx *sx, n_type_gfx *sy )
{

	if (  x == NULL ) { return; }
	if (  y == NULL ) { return; }
	if ( sx == NULL ) { return; }
	if ( sy == NULL ) { return; }


	// [!] : intercept useless BS_CENTER and BS_RIGHT


	if ( n_posix_false == n_win_class_is_same_literal( hgui, "Button" ) ) { return; }


	DWORD style = n_win_style_get( hgui );
	DWORD  type = style & 0x0000000f;

	if ( style & BS_ICON     ) { return; }
	if ( style & BS_BITMAP   ) { return; }
	if ( style & BS_PUSHLIKE ) { return; }


	n_posix_bool ownerdraw_c = n_win_property_get_literal( hgui, "n_win_move_patch_button().check" );
	n_posix_bool ownerdraw_r = n_win_property_get_literal( hgui, "n_win_move_patch_button().radio" );


	if (
		( type == BS_CHECKBOX        )
		||
		( type == BS_RADIOBUTTON     )
		||
		( type == BS_3STATE          )
		||
		( type == BS_AUTOCHECKBOX    )
		||
		( type == BS_AUTORADIOBUTTON )
		||
		( type == BS_AUTO3STATE      )
		||
		( ownerdraw_c )
		||
		( ownerdraw_r )
	)
	{

		n_type_int    cch = n_win_text_len( hgui );
		n_posix_char *str = n_string_new( cch ); n_win_text_get( hgui, str, (int) cch + 1 );


		n_type_gfx radio_check_size = 0;
		if (
			( type == BS_RADIOBUTTON     )
			||
			( type == BS_AUTORADIOBUTTON )
			||
			( ownerdraw_r )
		)
		{
			radio_check_size = n_win_stdsize_radio( hgui );
		} else {
			radio_check_size = n_win_stdsize_check( hgui );
		}

		n_type_gfx m = radio_check_size / 3;


		n_type_gfx tsx,tsy; n_win_stdsize_text( hgui, str, &tsx,&tsy );

		tsx += radio_check_size;

		tsx += ( m * 4 );
		tsy += ( m * 4 );

		if ( ( ownerdraw_c )||( ownerdraw_r ) )
		{
			//tsx += m;
		}


		if ( style & WS_BORDER )
		{
			tsx += 1 * 4;
		}


		n_string_free( str );


		// BS_LEFT   : 0000 0000 0000 0000 | 0000 0001 0000 0000
		// BS_RIGHT  : 0000 0000 0000 0000 | 0000 0010 0000 0000
		// BS_CENTER : 0000 0000 0000 0000 | 0000 0011 0000 0000
		// BS_TOP    : 0000 0000 0000 0000 | 0000 0100 0000 0000
		// BS_BOTTOM : 0000 0000 0000 0000 | 0000 1000 0000 0000

		style &= 0x00000f00;
		style &= BS_CENTER;

/*
n_win_hwndprintf_literal
(
	GetParent( hgui ),
	"%0x : %0x / %0x / %0x",
	(int) style, BS_LEFT, BS_RIGHT, BS_CENTER
);
*/

		//if ( (*sx) > tsx )
		{

			if ( style == BS_RIGHT  )
			{
				(*x) += ( (*sx) - tsx );
			} else
			if ( style == BS_CENTER )
			{
				(*x) += ( (*sx) - tsx ) / 2;
			}

			(*sx) = tsx;

		}

		//(*y) += ( (*sy) - tsy ) / 2;

	}


	return;
}

// internal
void
n_win_move_patch_scroll( HWND hgui, n_type_gfx *x, n_type_gfx *y, n_type_gfx *sx, n_type_gfx *sy )
{

	if (  x == NULL ) { return; }
	if (  y == NULL ) { return; }
	if ( sx == NULL ) { return; }
	if ( sy == NULL ) { return; }


	// [!] : minimum size patch


	if ( n_posix_false == n_win_class_is_same_literal( hgui, "Scrollbar" ) ) { return; }


	n_type_gfx m;
	n_win_stdsize( hgui, NULL, NULL, &m );


	DWORD style = n_win_style_get( hgui );
	DWORD type  = style & 0x00000001;

	if ( style & SBS_SIZEGRIP )
	{

		n_type_gfx tsx = GetSystemMetrics( SM_CXVSCROLL ) + ( m * 2 );
		n_type_gfx tsy = GetSystemMetrics( SM_CYHSCROLL ) + ( m * 2 );

		*x  += ( *sx - tsx ) / 2;
		*y  += ( *sy - tsy ) / 2;
		*sx  = tsx;
		*sy  = tsy;

	} else
	if ( type == SBS_HORZ )
	{

		n_type_gfx tsy = GetSystemMetrics( SM_CYHSCROLL ) + ( m * 2 );

		*y  += ( *sy - tsy ) / 2;
		*sy  = tsy;

	} else
	if ( type == SBS_VERT )
	{

		n_type_gfx tsx = GetSystemMetrics( SM_CXVSCROLL ) + ( m * 2 );

		*x  += ( *sx - tsx ) / 2;
		*sx  = tsx;

	}


	return;
}

#define n_win_move_simple MoveWindow

void
n_win_move( HWND hgui, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, n_posix_bool redraw )
{

	// [Mechanism] : standard compliant resizer
	//
	//	for theme and DPI setting
	//
	//	1 : n_win_stdsize() : get margin size
	//	2 : client size     : add margin size
	//	3 : n_win_set()     : resize a parent window
	//	4 : client size     : subtract margin size
	//	5 : n_win_move()    : move and resize child controls
	//
	//	[ Behavior ]
	//
	//	a : add offset around client area ( margin / 2 )
	//	b : add margin around control size
	//	c : some useless style will be expanded
	//	d : auto-adjust to standard size


	n_win_move_patch_button( hgui, &x, &y, &sx, &sy );
	n_win_move_patch_scroll( hgui, &x, &y, &sx, &sy );


	n_type_gfx m;
	n_win_stdsize( hgui, NULL, NULL, &m );


	 x += m / 2;
	 y += m / 2;

	 x += m;
	 y += m;
	sx -= m * 2;
	sy -= m * 2;

	n_win_move_simple( hgui, x,y,sx,sy, redraw );


	return;
}


#endif // _H_NONNON_WIN32_WIN_MOVE

